
package com.procam

import android.Manifest
import android.app.AlertDialog
import android.content.pm.PackageManager
import android.graphics.*
import android.os.Bundle
import android.os.Environment
import android.view.MotionEvent
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.io.*
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

class MainActivity : AppCompatActivity() {
    lateinit var preview: PreviewView
    lateinit var ui: ProCamView
    var imageCapture: ImageCapture? = null
    var provider: ProcessCameraProvider? = null
    var front = false

    var widthPx = 2736
    var heightPx = 3648
    var targetKb = 750
    var quality = 82
    var format = "JPG"
    var iso = 100
    var shutter = "1/250 s"
    var exposure = 0f
    var wb = "Auto"
    var focus = "Auto"
    var zoom = 1f
    var lastFile: File? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(7,8,11)
        window.navigationBarColor = Color.rgb(7,8,11)

        val root = android.widget.FrameLayout(this)
        preview = PreviewView(this).apply {
            scaleType = PreviewView.ScaleType.FILL_CENTER
        }
        root.addView(preview, android.widget.FrameLayout.LayoutParams(-1,-1))
        ui = ProCamView(this)
        root.addView(ui, android.widget.FrameLayout.LayoutParams(-1,-1))
        setContentView(root)

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED)
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.CAMERA), 50)
        else startCamera()
    }

    override fun onRequestPermissionsResult(r:Int,p:Array<out String>,g:IntArray) {
        super.onRequestPermissionsResult(r,p,g)
        if (r==50 && g.isNotEmpty() && g[0]==PackageManager.PERMISSION_GRANTED) startCamera()
    }

    fun startCamera() {
        val f=ProcessCameraProvider.getInstance(this)
        f.addListener({
            provider=f.get()
            bindCamera()
        }, ContextCompat.getMainExecutor(this))
    }

    fun bindCamera() {
        val p=provider ?: return
        val previewUse=Preview.Builder().build().also{it.surfaceProvider=preview.surfaceProvider}
        imageCapture=ImageCapture.Builder()
            .setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY)
            .setJpegQuality(quality)
            .build()
        p.unbindAll()
        try {
            p.bindToLifecycle(
                this,
                if(front) CameraSelector.DEFAULT_FRONT_CAMERA else CameraSelector.DEFAULT_BACK_CAMERA,
                previewUse,
                imageCapture
            )
        } catch(e:Exception) {
            Toast.makeText(this,"Camera not supported on this device",Toast.LENGTH_SHORT).show()
        }
    }

    fun switchCamera(){ front=!front; bindCamera(); ui.invalidate() }

    fun capture() {
        val c=imageCapture ?: return
        val raw=File(getExternalFilesDir(Environment.DIRECTORY_PICTURES),
            "raw_${System.currentTimeMillis()}.jpg")
        val options=ImageCapture.OutputFileOptions.Builder(raw).build()
        c.takePicture(options,ContextCompat.getMainExecutor(this),
            object:ImageCapture.OnImageSavedCallback{
                override fun onError(e:ImageCaptureException){
                    Toast.makeText(this@MainActivity,"Capture failed",Toast.LENGTH_SHORT).show()
                }
                override fun onImageSaved(r:ImageCapture.OutputFileResults){ compressAndSave(raw) }
            })
    }

    private fun compressAndSave(raw:File) {
        Thread {
            try {
                val source=BitmapFactory.decodeFile(raw.absolutePath) ?: return@Thread
                val scaled=Bitmap.createScaledBitmap(source,widthPx,heightPx,true)
                var q=quality.coerceIn(1,100)
                var best=ByteArray(0)
                repeat(12) {
                    val b=ByteArrayOutputStream()
                    scaled.compress(Bitmap.CompressFormat.JPEG,q,b)
                    best=b.toByteArray()
                    val kb=max(1,best.size/1024)
                    if(abs(kb-targetKb)<=5) return@repeat
                    q=if(kb>targetKb) max(5,q-5) else min(100,q+3)
                }
                val out=File(getExternalFilesDir(Environment.DIRECTORY_PICTURES),
                    "PROCAM_"+SimpleDateFormat("yyyyMMdd_HHmmss",Locale.US).format(Date())+".jpg")
                out.writeBytes(best)
                raw.delete()
                source.recycle(); scaled.recycle()
                lastFile=out
                runOnUiThread {
                    ui.screen=ProCamView.Screen.INFO
                    ui.invalidate()
                    Toast.makeText(this,"Saved • ${out.length()/1024} KB",Toast.LENGTH_SHORT).show()
                }
            } catch(_:Exception) {
                runOnUiThread { Toast.makeText(this,"Could not process photo",Toast.LENGTH_SHORT).show() }
            }
        }.start()
    }

    fun editNumber(title:String, value:String, onDone:(String)->Unit) {
        val e=EditText(this).apply{setText(value);selectAll()}
        AlertDialog.Builder(this).setTitle(title).setView(e)
            .setPositiveButton("Apply"){_,_->onDone(e.text.toString());ui.invalidate()}
            .setNegativeButton("Cancel",null).show()
    }
}

class ProCamView(private val a:MainActivity):View(a) {
    enum class Screen{CAMERA,SETTINGS,MANUAL,INFO}
    var screen=Screen.CAMERA

    private val bg=Color.rgb(7,8,11)
    private val card=Color.rgb(16,18,23)
    private val card2=Color.rgb(23,26,33)
    private val stroke=Color.rgb(48,53,64)
    private val text=Color.WHITE
    private val sub=Color.rgb(163,171,187)
    private val accent=Color.rgb(196,210,237)
    private val accentText=Color.rgb(18,20,25)

    private val p=Paint(Paint.ANTI_ALIAS_FLAG)

    override fun onDraw(c:Canvas){
        c.drawColor(bg)
        when(screen){
            Screen.CAMERA->camera(c)
            Screen.SETTINGS->settings(c)
            Screen.MANUAL->manual(c)
            Screen.INFO->info(c)
        }
    }

    private fun font(size:Float,color:Int=text,bold:Boolean=false){
        p.style=Paint.Style.FILL
        p.color=color
        p.textSize=size
        p.typeface=if(bold) Typeface.create("sans",Typeface.BOLD) else Typeface.create("sans",Typeface.NORMAL)
    }
    private fun t(c:Canvas,s:String,x:Float,y:Float,size:Float,color:Int=text,bold:Boolean=false){
        font(size,color,bold);c.drawText(s,x,y,p)
    }
    private fun center(c:Canvas,s:String,x:Float,y:Float,size:Float,color:Int=text,bold:Boolean=false){
        font(size,color,bold);c.drawText(s,x-p.measureText(s)/2f,y,p)
    }
    private fun box(c:Canvas,l:Float,t:Float,r:Float,b:Float,radius:Float,color:Int,strokeColor:Int?=null){
        p.style=Paint.Style.FILL;p.color=color;c.drawRoundRect(l,t,r,b,radius,radius,p)
        if(strokeColor!=null){p.style=Paint.Style.STROKE;p.strokeWidth=1f;p.color=strokeColor;c.drawRoundRect(l,t,r,b,radius,radius,p);p.style=Paint.Style.FILL}
    }
    private fun icon(c:Canvas,x:Float,y:Float,type:Int,active:Boolean=false){
        p.color=if(active) text else sub;p.style=Paint.Style.STROKE;p.strokeWidth=2.4f
        when(type){
            0->{c.drawRect(x-10,y-7,x+10,y+8,p);c.drawCircle(x,y,5,p);c.drawRect(x-6,y-12,x+1,y-7,p)}
            1->{c.drawLine(x-12,y-5,x+12,y-5,p);c.drawLine(x-12,y+5,x+12,y+5,p);c.drawCircle(x-4,y-5,2.5f,p);c.drawCircle(x+5,y+5,2.5f,p)}
            2->{c.drawRect(x-9,y-12,x+9,y+12,p);c.drawLine(x-4,y-3,x+4,y-3,p);c.drawLine(x-4,y+3,x+4,y+3,p)}
            3->{c.drawCircle(x,y,10,p);c.drawCircle(x,y,4,p)}
            4->{c.drawCircle(x,y,9,p);c.drawLine(x-13,y,x-7,y,p);c.drawLine(x+7,y,x+13,y,p);c.drawLine(x,y-13,x,y-7,p);c.drawLine(x,y+7,x,y+13,p)}
            5->{c.drawRect(x-11,y-7,x+11,y+8,p);c.drawCircle(x,y,5,p)}
        }
        p.style=Paint.Style.FILL
    }
    private fun pill(c:Canvas,l:Float,t:Float,r:Float,b:Float,label:String,on:Boolean=false){
        box(c,l,t,r,b,18f,if(on)accent else card2,if(on)accent else stroke)
        center(c,label,(l+r)/2,t+(b-t)/2+4,11f,if(on)accentText else text,on)
    }
    private fun header(c:Canvas,title:String){
        t(c,"‹",18f,50f,36f)
        center(c,title,width/2f,47f,16f,text,true)
        line(c,20f,68f,width-20f,68f)
    }
    private fun line(c:Canvas,x1:Float,y1:Float,x2:Float,y2:Float){
        p.color=stroke;p.strokeWidth=1f;c.drawLine(x1,y1,x2,y2,p)
    }

    private fun camera(c:Canvas){
        // Transparent overlay leaves the real CameraX preview visible.
        p.color=0x28000000;c.drawRect(0f,0f,width.toFloat(),height*0.69f,p)

        t(c,"⚙",25f,43f,22f)
        t(c,"ϟ",width*.28f,43f,24f)
        box(c,width*.42f,18f,width*.50f,47f,7f,0xAA08090C.toInt())
        center(c,"RAW",width*.46f,38f,9f,text,true)
        icon(c,width-34f,33f,0)

        val top=height*.68f
        box(c,0f,top,width.toFloat(),height.toFloat(),0f,0xE607080B.toInt())
        stat(c,"ISO",a.iso.toString(),44f,top)
        stat(c,"1/250",a.shutter,width*.31f,top)
        stat(c,"WB",a.wb,width*.58f,top)
        stat(c,"AF",if(a.focus=="Auto")"Single" else "Manual",width*.82f,top)

        center(c,"0.5",width*.20f,top+92,11f,sub)
        pill(c,width*.37f,top+69,width*.54f,top+105,"1.0x",true)
        center(c,"2.0",width*.63f,top+92,11f,sub)
        center(c,"5.0",width*.78f,top+92,11f,sub)

        val bottom=height-90f
        center(c,"▧",50f,bottom+18,20f,sub)
        center(c,"Gallery",50f,bottom+42,10f,sub)
        p.color=Color.WHITE;c.drawCircle(width/2f,bottom-5,32f,p)
        p.color=bg;c.drawCircle(width/2f,bottom-5,27f,p)
        center(c,"●",width/2f,bottom+2,17f,text)
        center(c,"Camera",width/2f,bottom+42,10f,text,true)
        center(c,"⚙",width-48f,bottom+18,20f,sub)
        center(c,"Settings",width-48f,bottom+42,10f,sub)
    }
    private fun stat(c:Canvas,title:String,value:String,x:Float,y:Float){
        t(c,title,x,y+31,10f,sub,true)
        t(c,value,x,y+52,13f,text)
    }

    private fun settings(c:Canvas){
        header(c,"Camera Settings")
        pill(c,22f,84f,width*.32f,119f,"Photo",true)
        pill(c,width*.34f,84f,width*.65f,119f,"Video")
        pill(c,width*.67f,84f,width-22f,119f,"Advanced")

        settingCard(c,135f,100f,"Resolution",2)
        t(c,"Width",38f,189f,12f,sub);t(c,"${a.widthPx} px",width-106f,189f,12f,text)
        circleButton(c,width-72f,185f,"−");circleButton(c,width-37f,185f,"+")
        t(c,"Height",38f,218f,12f,sub);t(c,"${a.heightPx} px",width-106f,218f,12f,text)
        circleButton(c,width-72f,214f,"−");circleButton(c,width-37f,214f,"+")
        t(c,"Total Pixels",38f,247f,12f,sub)
        t(c,String.format(Locale.US,"%.1f MP",a.widthPx*a.heightPx/1e6),width-92f,247f,12f,text)

        simpleRow(c,264f,"Aspect Ratio","3:4",1)
        simpleRow(c,328f,"File Size (Target)","${a.targetKb} KB",2)

        box(c,20f,397f,width-20f,475f,17f,card,stroke)
        icon(c,47f,424f,2);t(c,"Format",72f,429f,13f,text,true)
        pill(c,42f,442f,102f,471f,"JPG",a.format=="JPG")
        pill(c,111f,442f,171f,471f,"PNG",a.format=="PNG")
        pill(c,178f,442f,247f,471f,"WebP",a.format=="WebP")

        box(c,20f,484f,width-20f,565f,17f,card,stroke)
        t(c,"Quality (Compression)",42f,512f,13f,text,true)
        t(c,"${a.quality}%",width-69f,512f,12f,sub)
        slider(c,42f,534f,width-42f,a.quality/100f)

        box(c,20f,576f,width-20f,657f,17f,card,stroke)
        t(c,"Image Preview Info",42f,603f,13f,text,true)
        t(c,"Estimated size: ~${a.targetKb} KB",42f,625f,10f,sub)
        t(c,"Pixels: ${a.widthPx} × ${a.heightPx} (${String.format(Locale.US,"%.1f",a.widthPx*a.heightPx/1e6)} MP)",42f,641f,10f,sub)

        box(c,42f,675f,width-42f,720f,23f,accent)
        center(c,"Apply",width/2f,704f,13f,accentText,true)
    }

    private fun settingCard(c:Canvas,y:Float,h:Float,title:String,type:Int){
        box(c,20f,y,width-20f,y+h,17f,card,stroke)
        icon(c,47f,y+27,type)
        t(c,title,72f,y+31f,13f,text,true)
    }
    private fun simpleRow(c:Canvas,y:Float,title:String,value:String,type:Int){
        box(c,20f,y,width-20f,y+53f,16f,card,stroke)
        icon(c,47f,y+26f,type)
        t(c,title,72f,y+31f,13f,text,true)
        t(c,value,width-76f,y+31f,12f,sub)
        t(c,"›",width-39f,y+32f,22f,sub)
    }
    private fun circleButton(c:Canvas,x:Float,y:Float,s:String){
        p.color=card2;p.style=Paint.Style.FILL;c.drawCircle(x,y,13f,p)
        center(c,s,x,y+4,13f,text,true)
    }
    private fun slider(c:Canvas,l:Float,y:Float,r:Float,v:Float){
        box(c,l,y-2,r,y+2,3f,Color.rgb(55,61,73))
        box(c,l,y-2,l+(r-l)*v,y+2,3f,accent)
        p.color=Color.WHITE;c.drawCircle(l+(r-l)*v,y,6f,p)
    }

    private fun manual(c:Canvas){
        header(c,"Manual Controls")
        pill(c,22f,84f,width*.49f,119f,"Photo",true)
        pill(c,width*.51f,84f,width-22f,119f,"Video")

        sliderCard(c,135f,"ISO",a.iso.toString(),0.16f,1)
        sliderCard(c,235f,"Shutter Speed",a.shutter,0.52f,2)
        sliderCard(c,335f,"Exposure (EV)",String.format(Locale.US,"%.1f",a.exposure),0.50f,3)

        box(c,20f,435f,width-20f,525f,17f,card,stroke)
        t(c,"White Balance",42f,463f,13f,text,true);t(c,a.wb,width-79f,463f,12f,sub);t(c,"›",width-40f,464f,22f,sub)
        pill(c,42f,480f,103f,511f,"AWB",a.wb=="Auto")
        pill(c,112f,480f,169f,511f,"☀")
        pill(c,176f,480f,234f,511f,"☁")
        pill(c,241f,480f,299f,511f,"◉")

        box(c,20f,535f,width-20f,616f,17f,card,stroke)
        t(c,"Focus",42f,564f,13f,text,true);t(c,a.focus,width-79f,564f,12f,sub)
        pill(c,42f,578f,120f,609f,"AF",a.focus=="Auto")
        pill(c,128f,578f,206f,609f,"MF",a.focus=="Manual")
        t(c,"⌖",width-54f,600f,20f,text)

        box(c,20f,626f,width-20f,708f,17f,card,stroke)
        t(c,"Zoom",42f,654f,13f,text,true);t(c,"${a.zoom}x",width-70f,654f,12f,sub)
        pill(c,42f,669f,103f,701f,"0.5x",a.zoom==.5f)
        pill(c,111f,669f,175f,701f,"1.0",a.zoom==1f)
        pill(c,181f,669f,245f,701f,"2.0",a.zoom==2f)
        pill(c,251f,669f,315f,701f,"5.0",a.zoom==5f)
    }

    private fun sliderCard(c:Canvas,y:Float,title:String,value:String,position:Float,type:Int){
        box(c,20f,y,width-20f,y+88f,17f,card,stroke)
        icon(c,47f,y+27f,type+3)
        t(c,title,72f,y+31f,13f,text,true)
        t(c,value,width-76f,y+31f,12f,sub)
        slider(c,42f,y+53f,width-42f,position)
        t(c,if(type==1)"50" else if(type==2)"1/8000" else "-3",42f,y+75f,9f,sub)
        t(c,if(type==1)"3200" else if(type==2)"30" else "+3",width-57f,y+75f,9f,sub)
        box(c,width-55f,y+42f,width-28f,y+69f,7f,card2,stroke)
        center(c,"A",width-41.5f,y+60f,10f,text,true)
    }

    private fun info(c:Canvas){
        header(c,"Photo Info")
        box(c,20f,88f,width-20f,315f,17f,card2,stroke)
        // A clean preview placeholder representing the captured image.
        box(c,32f,100f,width-32f,238f,12f,Color.rgb(25,38,53))
        center(c,"PHOTO PREVIEW",width/2f,174f,12f,sub,true)
        line(c,32f,238f,width-32f,238f)
        row(c,253f,"Resolution","${a.widthPx} × ${a.heightPx} px")
        row(c,276f,"Pixels",String.format(Locale.US,"%.1f MP",a.widthPx*a.heightPx/1e6))
        row(c,299f,"File Size","${a.lastFile?.length()?.div(1024) ?: a.targetKb} KB")

        box(c,20f,330f,width-20f,526f,17f,card,stroke)
        t(c,"Camera Settings",42f,360f,14f,text,true)
        row(c,390f,"ISO",a.iso.toString());row(c,418f,"Shutter Speed",a.shutter)
        row(c,446f,"Exposure",String.format(Locale.US,"%.1f EV",a.exposure))
        row(c,474f,"White Balance",a.wb);row(c,502f,"Focus",a.focus);row(c,530f,"Zoom","${a.zoom}x")

        pill(c,30f,550f,width*.30f,590f,"↗ Share")
        pill(c,width*.35f,550f,width*.65f,590f,"↓ Save",true)
        pill(c,width*.70f,550f,width-30f,590f,"⌫ Delete")
    }
    private fun row(c:Canvas,y:Float,label:String,value:String){
        t(c,label,42f,y,11f,sub);t(c,value,width-44f-p.measureText(value),y,11f,text)
    }

    override fun onTouchEvent(e:MotionEvent):Boolean{
        if(e.action!=MotionEvent.ACTION_UP)return true
        val x=e.x;val y=e.y
        when(screen){
            Screen.CAMERA->{
                if(y<70f && x<80f){screen=Screen.SETTINGS;invalidate()}
                else if(y<70f && x>width-75f){a.switchCamera()}
                else if(y>height-150f && x>width*.35f && x<width*.65f)a.capture()
                else if(y>height-150f && x>width*.68f){screen=Screen.SETTINGS;invalidate()}
                else if(y>height-150f && x<width*.32f){screen=Screen.INFO;invalidate()}
            }
            Screen.SETTINGS->{
                if(y<70f){screen=Screen.CAMERA;invalidate()}
                else if(y in 135f..260f){
                    val box=LinearLayout(a);box.orientation=LinearLayout.VERTICAL
                    val w=EditText(a);w.setText(a.widthPx.toString());w.hint="Width (px)"
                    val h=EditText(a);h.setText(a.heightPx.toString());h.hint="Height (px)"
                    box.addView(w);box.addView(h)
                    AlertDialog.Builder(a).setTitle("Resolution").setView(box)
                        .setPositiveButton("Apply"){_,_->a.widthPx=w.text.toString().toIntOrNull()?:a.widthPx;a.heightPx=h.text.toString().toIntOrNull()?:a.heightPx;invalidate()}
                        .setNegativeButton("Cancel",null).show()
                } else if(y in 264f..327f)a.editNumber("Aspect Ratio","3:4"){}
                else if(y in 328f..395f)a.editNumber("Target File Size (KB)",a.targetKb.toString()){a.targetKb=(it.toIntOrNull()?:a.targetKb).coerceAtLeast(1)}
                else if(y in 397f..478f){
                    AlertDialog.Builder(a).setTitle("Format").setItems(arrayOf("JPG","PNG","WebP")){_,i->a.format=arrayOf("JPG","PNG","WebP")[i];invalidate()}.show()
                } else if(y>480f && y<570f){
                    a.editNumber("Quality (1–100)",a.quality.toString()){a.quality=(it.toIntOrNull()?:a.quality).coerceIn(1,100);a.bindCamera()}
                } else if(y>650f){screen=Screen.CAMERA;invalidate()}
            }
            Screen.MANUAL->{
                if(y<70f){screen=Screen.CAMERA;invalidate()}
                else if(y in 135f..225f)a.editNumber("ISO",a.iso.toString()){a.iso=(it.toIntOrNull()?:100).coerceIn(50,3200);invalidate()}
                else if(y in 235f..325f)a.editNumber("Shutter Speed",a.shutter){a.shutter=it;invalidate()}
                else if(y in 335f..430f)a.editNumber("Exposure EV",a.exposure.toString()){a.exposure=(it.toFloatOrNull()?:0f).coerceIn(-3f,3f);invalidate()}
                else if(y in 435f..530f)AlertDialog.Builder(a).setTitle("White Balance").setItems(arrayOf("Auto","Daylight","Cloudy","Tungsten","Fluorescent")){_,i->a.wb=arrayOf("Auto","Daylight","Cloudy","Tungsten","Fluorescent")[i];invalidate()}.show()
                else if(y in 535f..620f)AlertDialog.Builder(a).setTitle("Focus").setItems(arrayOf("Auto","Manual")){_,i->a.focus=arrayOf("Auto","Manual")[i];invalidate()}.show()
                else if(y>620f)AlertDialog.Builder(a).setTitle("Zoom").setItems(arrayOf("0.5x","1.0x","2.0x","5.0x")){_,i->a.zoom=arrayOf(.5f,1f,2f,5f)[i];invalidate()}.show()
            }
            Screen.INFO->{if(y<70f){screen=Screen.CAMERA;invalidate()}}
        }
        return true
    }
}
