# ProCam — Design Specification

Reference: the approved ProCam concept image from this conversation.

Visual system:
- Background: #08090C
- Primary cards: #121419
- Secondary cards: #191C23
- Main text: #FFFFFF
- Secondary text: #A5ADBC
- Accent: #BECDE8 (cool pale blue; implementation uses #BECDE8)
- Rounded cards: 18dp
- Compact pill controls: 20dp radius
- Portrait-first layout
- Camera preview occupies the upper visual area
- Four primary experiences: Camera, Camera Settings, Manual Controls, Photo Info
- Bottom navigation: Gallery / Camera / Settings
- Main capture control: circular, centered
- Settings are editable rather than fixed presets.

Functional requirements:
1. Custom width and height in pixels.
2. Automatic megapixel calculation.
3. Custom target file size in KB.
4. JPG/PNG/WebP selection.
5. Compression-quality control.
6. ISO, shutter speed, exposure, white balance, focus and zoom controls.
7. Front/rear camera switching.
8. Live camera preview.
9. Capture and save.
10. Photo information after capture.
11. Iterative JPEG compression to approach the requested KB target.
12. Device-dependent manual camera controls must be exposed only when supported.

Important:
A target file size is an optimization target, not a mathematical guarantee. Image content affects compression size.
