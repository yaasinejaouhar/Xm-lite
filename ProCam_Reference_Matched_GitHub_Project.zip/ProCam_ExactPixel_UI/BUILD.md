## Build

Open the project in Android Studio and run Gradle sync.

Recommended:
- Android Studio current stable
- Android SDK 35
- Android device with Camera2 support

The UI is intentionally implemented natively so controls can become real camera controls rather than being a static mockup.
