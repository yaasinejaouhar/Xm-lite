# ProCam — Reference-Matched Android App

This revision is rebuilt around the approved reference image, rather than the earlier generic approximation.

The UI uses the same visual language:
- near-black #07080B background
- rounded dark cards
- cool pale-blue selected controls
- white/muted typography
- compact icon buttons
- Camera Settings, Manual Controls and Photo Info screens
- Gallery / Camera / Settings bottom navigation
- custom resolution, target file size, quality and format
- ISO, shutter, exposure, white balance, focus and zoom
- real CameraX preview and capture

### Phone-only build
The included `.github/workflows/android.yml` builds a debug APK on GitHub Actions. Push the project to GitHub, open **Actions**, run **Build ProCam APK**, then download the generated `ProCam-debug-apk` artifact.

A literal pixel-for-pixel guarantee cannot be made across Android devices because fonts, status bars, camera previews and screen sizes vary. The layout itself is deliberately reference-matched.
