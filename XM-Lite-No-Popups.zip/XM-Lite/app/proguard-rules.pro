# XM Lite: no custom ProGuard rules required.
