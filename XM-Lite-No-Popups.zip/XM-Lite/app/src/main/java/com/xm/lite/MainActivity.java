package com.xm.lite;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.webkit.CookieManager;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.ProgressBar;

public class MainActivity extends Activity {
    private static final String HOME = "https://themoviebox.xyz/";
    private WebView webView;
    private View loadingOverlay;

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);

        webView = new WebView(this);
        webView.setBackgroundColor(Color.BLACK);
        root.addView(webView, new FrameLayout.LayoutParams(-1, -1));

        FrameLayout card = new FrameLayout(this);
        card.setBackgroundColor(0xCC111111);
        int pad = dp(12);
        card.setPadding(pad, pad, pad, pad);
        FrameLayout.LayoutParams cardLp = new FrameLayout.LayoutParams(dp(52), dp(52));
        cardLp.gravity = Gravity.CENTER;

        ProgressBar spinner = new ProgressBar(this);
        spinner.setIndeterminateDrawable(getResources().getDrawable(R.drawable.progress_ring));
        card.addView(spinner, new FrameLayout.LayoutParams(-1, -1));
        loadingOverlay = card;
        root.addView(loadingOverlay, cardLp);
        loadingOverlay.setVisibility(View.VISIBLE);

        setContentView(root);
        setupWebView();
        webView.loadUrl(HOME);
    }

    @SuppressLint("SetJavaScriptEnabled")
    private void setupWebView() {
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(false);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setSupportZoom(false);
        s.setLoadWithOverviewMode(false);
        s.setUseWideViewPort(false);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);

        CookieManager cookies = CookieManager.getInstance();
        cookies.setAcceptCookie(true);
        cookies.setAcceptThirdPartyCookies(webView, true);

        webView.setWebChromeClient(new WebChromeClient() {
            // Block JavaScript pop-up windows (window.open / target=_blank popups).
            @Override
            public boolean onCreateWindow(WebView view, boolean isDialog,
                                          boolean isUserGesture, android.os.Message resultMsg) {
                return false;
            }
        });
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return handleUrl(request.getUrl().toString());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return handleUrl(url);
            }

            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                String url = request.getUrl().toString();
                if (isLikelyAdOrPopup(url)) {
                    return new WebResourceResponse("text/plain", "UTF-8",
                            new java.io.ByteArrayInputStream(new byte[0]));
                }
                return super.shouldInterceptRequest(view, request);
            }

            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, String url) {
                if (isLikelyAdOrPopup(url)) {
                    return new WebResourceResponse("text/plain", "UTF-8",
                            new java.io.ByteArrayInputStream(new byte[0]));
                }
                return super.shouldInterceptRequest(view, url);
            }

            @Override
            public void onPageStarted(WebView view, String url, android.graphics.Bitmap favicon) {
                loadingOverlay.setVisibility(View.VISIBLE);
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                loadingOverlay.setVisibility(View.GONE);

                // Stop common web pop-up mechanisms and remove obvious ad overlays.
                String js =
                        "(function(){" +
                        "try{" +
                        "window.open=function(){return null;};" +
                        "document.addEventListener('click',function(e){" +
                        "var a=e.target.closest&&e.target.closest('a[target=_blank]');" +
                        "if(a){a.removeAttribute('target');}" +
                        "},true);" +
                        "}catch(e){}" +
                        "})();";
                view.evaluateJavascript(js, null);
            }
        });

        webView.setDownloadListener((url, userAgent, contentDisposition, mimeType, contentLength) -> {
            try {
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
            } catch (Exception ignored) { }
        });
    }

    private boolean isLikelyAdOrPopup(String url) {
        if (url == null) return false;
        String u = url.toLowerCase(java.util.Locale.US);

        // Common ad / pop-under URL patterns. This intentionally avoids
        // blocking normal site navigation and video/CDN requests.
        String[] patterns = {
                "doubleclick.net", "googlesyndication.com", "googleadservices.com",
                "adservice.google.com", "googletagmanager.com",
                "adnxs.com", "taboola.com", "outbrain.com",
                "popunder", "popunder", "popup", "/ads.", "/adserver",
                "bannerad", "clickunder"
        };

        for (String p : patterns) {
            if (u.contains(p)) return true;
        }
        return false;
    }

    private boolean handleUrl(String url) {
        if (url == null) return true;
        Uri uri = Uri.parse(url);
        String scheme = uri.getScheme();
        if ("http".equalsIgnoreCase(scheme) || "https".equalsIgnoreCase(scheme)) {
            webView.loadUrl(url);
            return true;
        }
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, uri));
        } catch (Exception ignored) { }
        return true;
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.stopLoading();
            webView.setWebChromeClient(null);
            webView.setWebViewClient(null);
            webView.destroy();
        }
        super.onDestroy();
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }
}
